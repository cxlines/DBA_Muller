const logoutButton = document.querySelector("#logout_button"),
    pwShowHide = document.querySelectorAll(".pw_hide");

pwShowHide.forEach((icon) => {
    icon.addEventListener("click", () => {
        let getPwInput = icon.parentElement.querySelector("input");
        if (getPwInput.type === "password") {
            getPwInput.type = "text";
            icon.classList.replace("uil-eye-slash", "uil-eye");
        } else {
            getPwInput.type = "password";
            icon.classList.replace("uil-eye", "uil-eye-slash");
        }
    });
});

logoutButton.addEventListener("click", function () {
    $.post({
        url: "/Session/Logout",
        success: function () {
            window.location.href = "index.html";
        },
    });
});
