using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("[Controller]/[action]")]
public class EntryController : Controller
{
  private const string ConnectionString = "Data Source=shema.sql;";

  private User? GetLoggedInUser()
  {
    var sessionId = Request.Cookies["sessionId"];
    if (sessionId == null)
    {
      return null;
    }

    SessionRepository sessionRepository = new SessionRepository(ConnectionString);
    var userId = sessionRepository.GetUserIdBySessionId(sessionId);
    if (userId == null)
    {
      return null;
    }

    UserRepository userRepository = new UserRepository(ConnectionString);
    var user = userRepository.GetById(userId.Value);

    return user;
  }

  [HttpPost]
  public IActionResult Create([FromForm] string title, [FromForm] string description)
  {
    var user = GetLoggedInUser();

    if (user == null)
    {
      var response = new
      {
        success = false,
        message = "Nem vagy bejelentkezve."
      };

      return Ok(response);
    }

    EntryRepository entryRepository = new EntryRepository(ConnectionString);
    entryRepository.CreateEntry(new Entry
    {
      AuthorUserID = user.Id,
      AuthorUserName = user.Name,
      Title = title,
      Description = description
    });

    var response2 = new
    {
      success = true,
      message = "Sikeresen létrehoztad a bejegyzést."
    };

    return Ok(response2);
  }

  [HttpGet]
  public IActionResult GetEntries()
  {
    EntryRepository entryRepository = new EntryRepository(ConnectionString);
    var entries = entryRepository.GetEntries();

    var response = new
    {
      success = true,
      entries = entries
    };

    return Ok(response);
  }

}