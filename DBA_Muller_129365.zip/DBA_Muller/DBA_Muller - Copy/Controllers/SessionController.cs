using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("[Controller]/[action]")]
public class SessionController : Controller
{
    private const string ConnectionString = "Data Source=shema.sql;";

    [HttpPost]
    public IActionResult Register([FromForm] string name, [FromForm] string email, [FromForm] string password)
    {
        // Generálja a jelszó hash-t és kapja meg a sót
        string hashedPassword, salt;
        hashedPassword = PasswordManager.GeneratePasswordHash(password, out salt);

        // Mentés az adatbázisba
        UserRepository userRepository = new UserRepository(ConnectionString);
        userRepository.CreateUser(name, email, hashedPassword, salt);

        var response = new
        {
            success = true,
            message = $"Üdvözlöm {name}!"
        };

        return Ok(response);
    }

    // TODO login with email rather then name
    [HttpPost]
    public IActionResult Login([FromForm] string name, [FromForm] string password)
    {
        // Retrieve user from the database by name
        UserRepository userRepository = new UserRepository(ConnectionString);
        var user = userRepository.GetByName(name);

        if (user != null && PasswordManager.Verify(password, user.Salt, user.PasswordHash))
        {
            SetSession(user);

            var response = new
            {
                success = true,
                message = $"Sikeres bejelentkezés: Üdvözlöm {name}!"
            };

            return Ok(response);
        }
        else
        {
            var response = new
            {
                success = false,
                message = "Hibás felhasználónév vagy jelszó."
            };

            return Ok(response);
        }
    }

    private void SetSession(User user)
    {
        // generate session id
        string sessionId = Guid.NewGuid().ToString();

        // save session id to cookie
        Response.Cookies.Append("sessionId", sessionId, new CookieOptions { HttpOnly = true });

        // save session id to database
        SessionRepository sessionRepository = new SessionRepository(ConnectionString);
        sessionRepository.CreateSession(sessionId, user.Id);
    }

    [HttpPost]
    public IActionResult Logout()
    {
        string? sessionId = Request.Cookies["sessionId"];
        if (sessionId != null)
        {
            // delete session id from database
            SessionRepository sessionRepository = new SessionRepository(ConnectionString);
            sessionRepository.DeleteSession(sessionId);
        }

        // delete session id from cookie
        Response.Cookies.Delete("sessionId");

        var response = new
        {
            success = true,
            message = "Sikeres kijelentkezés."
        };

        return Ok(response);
    }

    // get user information from session
    [HttpGet]
    public IActionResult GetUserInfo()
    {
        string? sessionId = Request.Cookies["sessionId"];
        if (sessionId != null)
        {
            // get user id from database
            SessionRepository sessionRepository = new SessionRepository(ConnectionString);
            int? userId = sessionRepository.GetUserIdBySessionId(sessionId);

            if (userId != null)
            {
                // get user from database
                UserRepository userRepository = new UserRepository(ConnectionString);
                var user = userRepository.GetById(userId.Value);

                var response = new
                {
                    success = true,
                    data = new
                    {
                        name = user?.Name,
                    }
                };

                return Ok(response);
            }
        }

        var errorResponse = new
        {
            success = false,
            message = "Sikertelen bejelentkezés."
        };

        return Ok(errorResponse);
    }

    // TODO delete this method
    [HttpPost]
    public string ClearDatabase()
    {
        UserRepository userRepository = new UserRepository(ConnectionString);
        userRepository.DeleteUsers();

        return "Adatbázis törölve.";
    }
}
