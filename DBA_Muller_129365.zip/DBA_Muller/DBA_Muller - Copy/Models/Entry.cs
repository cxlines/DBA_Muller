public class Entry
{
  public int Id { get; set; }
  public int AuthorUserID { get; set; }
  public string AuthorUserName { get; set; } = "";
  public string Title { get; set; } = "";
  public string Description { get; set; } = "";
}