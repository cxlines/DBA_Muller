using System.Data.SQLite;

public class EntryRepository
{

  private readonly string ConnectionString;

  public EntryRepository(string connectionString)
  {
    ConnectionString = connectionString;
  }

  private void CreateEntryTable(SQLiteConnection connection)
  {
    using (SQLiteCommand createTableCommand = new SQLiteCommand(
        "CREATE TABLE IF NOT EXISTS Entries (Id INTEGER PRIMARY KEY AUTOINCREMENT, AuthorUserID INTEGER, AuthorUserName TEXT, Title TEXT, Description TEXT);",
        connection))
    {
      createTableCommand.ExecuteNonQuery();
    }
  }

  public void CreateEntry(Entry entry)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      CreateEntryTable(connection);

    
      using (SQLiteCommand insertCommand = new SQLiteCommand(
          "INSERT INTO Entries (AuthorUserID, AuthorUserName, Title, Description) VALUES (@authorUserId, @authorUserName, @title, @description);",
          connection))
      {
        insertCommand.Parameters.AddWithValue("@authorUserId", entry.AuthorUserID);
        insertCommand.Parameters.AddWithValue("@authorUserName", entry.AuthorUserName);
        insertCommand.Parameters.AddWithValue("@title", entry.Title);
        insertCommand.Parameters.AddWithValue("@description", entry.Description);

        insertCommand.ExecuteNonQuery();
      }
    }
  }

  public Entry[] GetEntries()
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      CreateEntryTable(connection);

      // Lekérdezi az adatokat a táblából
      using (SQLiteCommand selectCommand = new SQLiteCommand(
          "SELECT * FROM Entries;",
          connection))
      {
        using (SQLiteDataReader reader = selectCommand.ExecuteReader())
        {
          List<Entry> entries = new List<Entry>();

          while (reader.Read())
          {
            entries.Add(new Entry
            {
              Id = Convert.ToInt32(reader["Id"]),
              AuthorUserID = Convert.ToInt32(reader["AuthorUserID"]),
              AuthorUserName = reader["AuthorUserName"].ToString() ?? "",
              Title = reader["Title"].ToString() ?? "",
              Description = reader["Description"].ToString() ?? "",
            });
          }

          return entries.ToArray();
        }
      }
    }
  }

}