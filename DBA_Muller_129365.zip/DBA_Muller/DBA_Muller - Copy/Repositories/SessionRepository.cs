using System.Data.SQLite;

public class SessionRepository
{

  private readonly string ConnectionString;

  public SessionRepository(string connectionString)
  {
    ConnectionString = connectionString;
  }

  public void CreateSession(string sessionId, int userId)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      
      using (SQLiteCommand createTableCommand = new SQLiteCommand(
          "CREATE TABLE IF NOT EXISTS Sessions (Id TEXT PRIMARY KEY, UserId INTEGER);",
          connection))
      {
        createTableCommand.ExecuteNonQuery();
      }

 
      using (SQLiteCommand insertCommand = new SQLiteCommand(
          "INSERT INTO Sessions (Id, UserId) VALUES (@sessionId, @userId);",
          connection))
      {
        insertCommand.Parameters.AddWithValue("@sessionId", sessionId);
        insertCommand.Parameters.AddWithValue("@userId", userId);

        insertCommand.ExecuteNonQuery();
      }
    }
  }

  public int? GetUserIdBySessionId(string sessionId)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      using (SQLiteCommand selectCommand = new SQLiteCommand(
          "SELECT UserId FROM Sessions WHERE Id = @sessionId;",
          connection))
      {
        selectCommand.Parameters.AddWithValue("@sessionId", sessionId);

        using (SQLiteDataReader reader = selectCommand.ExecuteReader())
        {
          if (reader.Read())
          {
            return Convert.ToInt32(reader["UserId"]);
          }
        }
      }
    }

    return null;
  }

  public void DeleteSession(string sessionId)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      using (SQLiteCommand deleteCommand = new SQLiteCommand(
          "DELETE FROM Sessions WHERE Id = @sessionId;",
          connection))
      {
        deleteCommand.Parameters.AddWithValue("@sessionId", sessionId);

        deleteCommand.ExecuteNonQuery();
      }
    }
  }

  public void DeleteAllSessions()
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      using (SQLiteCommand deleteCommand = new SQLiteCommand(
          "DELETE FROM Sessions;",
          connection))
      {
        deleteCommand.ExecuteNonQuery();
      }
    }
  }
}