using System.Data.SQLite;

public class UserRepository
{

  private readonly string ConnectionString;

  public UserRepository(string connectionString)
  {
    ConnectionString = connectionString;
  }

  public User? GetByName(string name)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      using (SQLiteCommand selectCommand = new SQLiteCommand(
          "SELECT * FROM Users WHERE Name = @name;",
          connection))
      {
        selectCommand.Parameters.AddWithValue("@name", name);

        using (SQLiteDataReader reader = selectCommand.ExecuteReader())
        {
          if (reader.Read())
          {
            
            return new User
            {
              Id = Convert.ToInt32(reader["Id"]),
              Name = reader["Name"].ToString() ?? "",
              Email = reader["Email"].ToString() ?? "",
              PasswordHash = reader["PasswordHash"].ToString() ?? "",
              Salt = reader["Salt"].ToString() ?? "",
            };
          }
        }
      }
    }

    return null;
  }

  public User? GetById(int id)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      using (SQLiteCommand selectCommand = new SQLiteCommand(
          "SELECT * FROM Users WHERE Id = @id;",
          connection))
      {
        selectCommand.Parameters.AddWithValue("@id", id);

        using (SQLiteDataReader reader = selectCommand.ExecuteReader())
        {
          if (reader.Read())
          {
            
            return new User
            {
              Id = Convert.ToInt32(reader["Id"]),
              Name = reader["Name"].ToString() ?? "",
              Email = reader["Email"].ToString() ?? "",
              PasswordHash = reader["PasswordHash"].ToString() ?? "",
              Salt = reader["Salt"].ToString() ?? "",
            };
          }
        }
      }
    }

    return null;
  }

  public void CreateUser(string name, string email, string hashedPassword, string salt)
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      
      using (SQLiteCommand createTableCommand = new SQLiteCommand(
          "CREATE TABLE IF NOT EXISTS Users (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Email TEXT, PasswordHash TEXT, Salt TEXT);",
          connection))
      {
        createTableCommand.ExecuteNonQuery();
      }

     
      using (SQLiteCommand insertCommand = new SQLiteCommand(
          "INSERT INTO Users (Name, Email, PasswordHash, Salt) VALUES (@name, @email, @hashedPassword, @salt);",
          connection))
      {
        insertCommand.Parameters.AddWithValue("@name", name);
        insertCommand.Parameters.AddWithValue("@email", email);
        insertCommand.Parameters.AddWithValue("@hashedPassword", hashedPassword);
        insertCommand.Parameters.AddWithValue("@salt", salt);

        insertCommand.ExecuteNonQuery();
      }
    }
  }

  
  public void DeleteUsers()
  {
    using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
    {
      connection.Open();

      using (SQLiteCommand deleteCommand = new SQLiteCommand(
          "DELETE FROM Users;",
          connection))
      {
        deleteCommand.ExecuteNonQuery();
      }
    }
  }

}